export default {
    primary: "#38EF7D",
    secondary: '#BFD041',
    white: "#fff",
    black: "black",
    grey: "#d5d5d5",
    darkGrey2: '#2D2D2D',
    darkGrey: '#707070',
    newInputFieldBorder: '#DEDEDE',
    inputFieldBorder: "#393939",
    inputFieldBackgroundColor: "#3C3C3C",
    inputFieldPlaceholder: "#9AA3AE",
};
